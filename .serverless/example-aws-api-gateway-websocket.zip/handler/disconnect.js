module.exports.handler = (event, _context, callback) => {
  callback(null, {statusCode: 200})
}
