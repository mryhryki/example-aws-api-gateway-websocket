module.exports.handler = (event, _context, callback) => {
  callback(null, {})
}
