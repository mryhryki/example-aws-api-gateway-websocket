# example-aws-api-gateway-websocket

## Setup

以下のコマンドを実行します。

```bash
$ npm run setup
```

`.env` ファイルが出来上がっているので、必要な環境変数に書き換えてください
